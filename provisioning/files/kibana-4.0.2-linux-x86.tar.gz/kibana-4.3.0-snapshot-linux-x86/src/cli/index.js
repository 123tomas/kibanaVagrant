'use strict';

require('babel/register')(require('../optimize/babelOptions').node);
require('./cli');
