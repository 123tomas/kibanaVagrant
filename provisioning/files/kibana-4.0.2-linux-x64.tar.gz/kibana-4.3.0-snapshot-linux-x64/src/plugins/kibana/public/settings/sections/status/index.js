define(function (require) {
  var _ = require('lodash');

  return {
    order: 3,
    name: 'status',
    display: 'Status',
    url: '/status'
  };
});
