'use strict';

require('d3');
require('@spalger/nvd3/build/nv.d3.css');
require('@spalger/nvd3/build/nv.d3.js');
require('@spalger/angular-nvd3/dist/angular-nvd3.min.js');
module.exports = window.nv;
