
This is my repository of Kibana using for University purposes.

This types of visualizations are now available under Visualize tab:


1. Chord chart
==============

alt tag


2. Relation chart
=================

alt tag


3. Spider chart
===============

alt tag
